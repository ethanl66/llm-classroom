# EC530-llm-classroom
cd doccli
doccli --help